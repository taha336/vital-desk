import Foundation

/// SAMPLE DATA FOR TESTING ONLY. These are not real doctors.
/// Real doctors will come from the backend (Firestore) in a later phase.
enum SampleDoctors {
    static let all: [Doctor] = [
        Doctor(
            id: "sample-1",
            name: "Dr. Aarav Mehta",
            specialization: "Cardiologist",
            experienceYears: 12,
            availableWeekdays: [2, 3, 4, 5, 6],
            slots: ["09:00", "10:00", "11:00", "14:00", "15:00", "16:00"]
        ),
        Doctor(
            id: "sample-2",
            name: "Dr. Sneha Iyer",
            specialization: "Dermatologist",
            experienceYears: 8,
            availableWeekdays: [2, 4, 6],
            slots: ["10:00", "11:00", "12:00", "15:00", "16:00"]
        ),
        Doctor(
            id: "sample-3",
            name: "Dr. Rohan Kulkarni",
            specialization: "Orthopedic",
            experienceYears: 15,
            availableWeekdays: [3, 5, 7],
            slots: ["09:00", "10:00", "11:00", "13:00", "14:00"]
        ),
        Doctor(
            id: "sample-4",
            name: "Dr. Fatima Khan",
            specialization: "Pediatrician",
            experienceYears: 10,
            availableWeekdays: [2, 3, 4, 5, 6, 7],
            slots: ["09:00", "09:30", "10:00", "10:30", "11:00", "11:30"]
        ),
        Doctor(
            id: "sample-5",
            name: "Dr. Vikram Sethi",
            specialization: "General Physician",
            experienceYears: 6,
            availableWeekdays: [2, 3, 4, 5, 6],
            slots: ["10:00", "11:00", "12:00", "16:00", "17:00", "18:00"]
        )
    ]
}
