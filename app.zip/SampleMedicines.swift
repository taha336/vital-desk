import Foundation

/// SAMPLE DATA FOR TESTING ONLY.
/// Names, prices and prescription flags here are NOT real catalogue data.
/// A real catalogue must come from a licensed pharmacy backend and follow local drug laws.
enum SampleMedicines {
    static let all: [Medicine] = [
        Medicine(id: "sample-med-1", name: "Paracetamol Tablets", packInfo: "Strip of 10 tablets",
                 price: 25, category: .painFever, requiresPrescription: false),
        Medicine(id: "sample-med-2", name: "Cetirizine Tablets", packInfo: "Strip of 10 tablets",
                 price: 30, category: .coldAllergy, requiresPrescription: false),
        Medicine(id: "sample-med-3", name: "ORS Sachets", packInfo: "Pack of 5 sachets",
                 price: 20, category: .digestive, requiresPrescription: false),
        Medicine(id: "sample-med-4", name: "Antacid Syrup", packInfo: "Bottle of 200 ml",
                 price: 95, category: .digestive, requiresPrescription: false),
        Medicine(id: "sample-med-5", name: "Vitamin C Chewable Tablets", packInfo: "Bottle of 30 tablets",
                 price: 120, category: .coldAllergy, requiresPrescription: false),
        Medicine(id: "sample-med-6", name: "Amoxicillin Capsules", packInfo: "Strip of 10 capsules",
                 price: 110, category: .painFever, requiresPrescription: true),
        Medicine(id: "sample-med-7", name: "Metformin Tablets", packInfo: "Strip of 15 tablets",
                 price: 45, category: .chronicCare, requiresPrescription: true),
        Medicine(id: "sample-med-8", name: "Amlodipine Tablets", packInfo: "Strip of 10 tablets",
                 price: 55, category: .chronicCare, requiresPrescription: true)
    ]
}
