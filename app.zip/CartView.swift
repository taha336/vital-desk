import SwiftUI
import PhotosUI

struct CartView: View {
    @Environment(CartStore.self) private var cart

    @State private var pickerItem: PhotosPickerItem?
    @State private var prescriptionImage: Image?
    @State private var showConfirm = false
    @State private var showDone = false

    private var totalText: String {
        cart.totalPrice.formatted(.currency(code: "INR"))
    }

    private var prescriptionNames: String {
        cart.lines
            .filter { $0.medicine.requiresPrescription }
            .map { $0.medicine.name }
            .joined(separator: ", ")
    }

    private var canPlaceOrder: Bool {
        !cart.lines.isEmpty && (!cart.needsPrescription || prescriptionImage != nil)
    }

    var body: some View {
        ZStack {
            AppTheme.background.ignoresSafeArea()

            if cart.lines.isEmpty {
                ContentUnavailableView(
                    "Your cart is empty",
                    systemImage: "cart",
                    description: Text("Add medicines from the catalogue.")
                )
            } else {
                ScrollView {
                    VStack(spacing: 16) {
                        itemsCard
                        if cart.needsPrescription {
                            prescriptionCard
                        }
                        summaryCard
                        placeOrderButton
                        note
                    }
                    .padding(16)
                }
            }
        }
        .navigationTitle("Cart")
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of: pickerItem) { _, newItem in
            loadImage(from: newItem)
        }
        .alert("Place demo order?", isPresented: $showConfirm) {
            Button("Place order") { placeOrder() }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Total \(totalText). This is a demo: nothing is sent to any pharmacy.")
        }
        .alert("Demo order recorded", isPresented: $showDone) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("No real order or payment was made. In a real app, a pharmacist would verify your prescription first.")
        }
    }

    // MARK: - Sections

    private var itemsCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Items")
                .font(.headline)

            ForEach(cart.lines) { line in
                HStack(spacing: 12) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(line.medicine.name)
                            .font(.subheadline.bold())
                        Text("\(line.medicine.priceText) each")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        if line.medicine.requiresPrescription {
                            Text("Prescription needed")
                                .font(.caption2.bold())
                                .foregroundStyle(.orange)
                        }
                    }

                    Spacer()

                    HStack(spacing: 10) {
                        Button {
                            cart.decrease(line.medicine)
                        } label: {
                            Image(systemName: "minus.circle.fill").font(.title3)
                        }
                        .accessibilityLabel("Decrease quantity")

                        Text("\(line.quantity)")
                            .font(.subheadline.bold())
                            .frame(minWidth: 20)

                        Button {
                            cart.add(line.medicine)
                        } label: {
                            Image(systemName: "plus.circle.fill").font(.title3)
                        }
                        .disabled(line.quantity >= CartStore.maxQuantity)
                        .accessibilityLabel("Increase quantity")

                        Button(role: .destructive) {
                            cart.remove(line.medicine)
                        } label: {
                            Image(systemName: "trash").font(.body)
                        }
                        .accessibilityLabel("Remove \(line.medicine.name)")
                    }
                    .foregroundStyle(AppTheme.primaryBlue)
                }

                if line.id != cart.lines.last?.id {
                    Divider()
                }
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 20))
        .shadow(color: .black.opacity(0.06), radius: 8, y: 4)
    }

    private var prescriptionCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Prescription required", systemImage: "doc.text.fill")
                .font(.headline)
                .foregroundStyle(.orange)

            Text("A valid prescription from a licensed doctor is needed for: \(prescriptionNames).")
                .font(.subheadline)

            PhotosPicker(selection: $pickerItem, matching: .images) {
                Label(prescriptionImage == nil ? "Attach prescription photo" : "Change photo",
                      systemImage: "photo.badge.plus")
                    .font(.subheadline.bold())
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(AppTheme.primaryBlue.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
            }

            if let prescriptionImage {
                prescriptionImage
                    .resizable()
                    .scaledToFit()
                    .frame(maxHeight: 180)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
            }

            Text("In a real app, a pharmacist verifies your prescription before dispatch. That verification is not connected in demo mode. This photo is kept in memory only and is never saved or sent.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.orange.opacity(0.10), in: RoundedRectangle(cornerRadius: 20))
    }

    private var summaryCard: some View {
        VStack(spacing: 10) {
            HStack {
                Text("Total items")
                Spacer()
                Text("\(cart.totalItems)")
            }
            Divider()
            HStack {
                Text("Total")
                    .font(.headline)
                Spacer()
                Text(totalText)
                    .font(.headline)
                    .foregroundStyle(AppTheme.teal)
            }
        }
        .font(.subheadline)
        .padding(16)
        .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 20))
        .shadow(color: .black.opacity(0.06), radius: 8, y: 4)
    }

    private var placeOrderButton: some View {
        VStack(spacing: 6) {
            Button {
                showConfirm = true
            } label: {
                Text("Place Order (Demo)")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(canPlaceOrder ? AppTheme.primaryBlue : Color.gray.opacity(0.4),
                                in: RoundedRectangle(cornerRadius: 16))
                    .foregroundStyle(.white)
            }
            .disabled(!canPlaceOrder)

            if cart.needsPrescription && prescriptionImage == nil {
                Text("Attach a prescription photo to continue.")
                    .font(.caption)
                    .foregroundStyle(.orange)
            }
        }
    }

    private var note: some View {
        Text("Demo mode: no real order or payment. VitalDesk does not give medical advice or dosage guidance.")
            .font(.caption)
            .foregroundStyle(.secondary)
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
    }

    // MARK: - Actions

    private func loadImage(from item: PhotosPickerItem?) {
        guard let item else {
            prescriptionImage = nil
            return
        }
        Task {
            if let data = try? await item.loadTransferable(type: Data.self),
               let uiImage = UIImage(data: data) {
                prescriptionImage = Image(uiImage: uiImage)
            }
        }
    }

    private func placeOrder() {
        cart.clear()
        pickerItem = nil
        prescriptionImage = nil
        showDone = true
    }
}

#Preview {
    NavigationStack {
        CartView()
    }
    .environment(CartStore())
}
