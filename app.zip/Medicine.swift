import Foundation

enum MedicineCategory: String, CaseIterable, Identifiable, Hashable {
    case painFever = "Pain & Fever"
    case coldAllergy = "Cold & Allergy"
    case digestive = "Digestive"
    case chronicCare = "Chronic Care"

    var id: String { rawValue }

    var systemImage: String {
        switch self {
        case .painFever: return "thermometer.medium"
        case .coldAllergy: return "wind"
        case .digestive: return "drop.fill"
        case .chronicCare: return "heart.text.square.fill"
        }
    }
}

struct Medicine: Identifiable, Hashable {
    let id: String
    let name: String
    let packInfo: String
    let price: Double
    let category: MedicineCategory
    let requiresPrescription: Bool

    var priceText: String {
        price.formatted(.currency(code: "INR"))
    }
}
