import SwiftUI

struct DoctorListView: View {
    @State private var searchText = ""

    private var doctors: [Doctor] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !query.isEmpty else { return SampleDoctors.all }
        return SampleDoctors.all.filter {
            $0.name.lowercased().contains(query) ||
            $0.specialization.lowercased().contains(query)
        }
    }

    var body: some View {
        ZStack {
            AppTheme.background.ignoresSafeArea()

            ScrollView {
                VStack(spacing: 16) {
                    demoBanner
                    SearchBar(text: $searchText, placeholder: "Search doctor or specialization")

                    if doctors.isEmpty {
                        ContentUnavailableView.search(text: searchText)
                    } else {
                        ForEach(doctors) { doctor in
                            NavigationLink {
                                DoctorDetailView(doctor: doctor)
                            } label: {
                                DoctorRow(doctor: doctor)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                .padding(16)
            }
        }
        .navigationTitle("Doctors")
        .navigationBarTitleDisplayMode(.inline)
    }

    private var demoBanner: some View {
        Label("Sample doctors for testing only. They are not real doctors. Bookings are saved on this phone only.",
              systemImage: "exclamationmark.triangle.fill")
            .font(.caption)
            .foregroundStyle(.orange)
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.orange.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
    }
}

private struct DoctorRow: View {
    let doctor: Doctor

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: "person.fill")
                .font(.title2)
                .foregroundStyle(AppTheme.primaryBlue)
                .frame(width: 56, height: 56)
                .background(AppTheme.primaryBlue.opacity(0.12), in: Circle())

            VStack(alignment: .leading, spacing: 4) {
                Text(doctor.name)
                    .font(.headline)
                    .foregroundStyle(.primary)
                Text(doctor.specialization)
                    .font(.subheadline)
                    .foregroundStyle(AppTheme.teal)
                Text("\(doctor.experienceYears) years experience")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text("Available: \(doctor.availabilityText)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Image(systemName: "chevron.right")
                .font(.footnote.bold())
                .foregroundStyle(.secondary)
        }
        .padding(14)
        .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 20))
        .shadow(color: .black.opacity(0.06), radius: 8, y: 4)
        .accessibilityElement(children: .combine)
    }
}

#Preview {
    NavigationStack {
        DoctorListView()
    }
}
