import SwiftUI
 
/// Screen for the "Online Consultation" tile on Home.
/// Shows the user's confirmed appointments; "Join video call" starts a Jitsi video call.
struct OnlineConsultationView: View {
    @Environment(AppointmentStore.self) private var store
 
    private var upcoming: [Appointment] {
        store.sortedAppointments.filter { $0.status == .confirmed }
    }
 
    var body: some View {
        ZStack {
            AppTheme.background.ignoresSafeArea()
 
            ScrollView {
                VStack(spacing: 16) {
                    infoCard
 
                    if upcoming.isEmpty {
                        emptyState
                    } else {
                        ForEach(upcoming) { appointment in
                            consultationCard(appointment)
                        }
                    }
                }
                .padding(16)
            }
        }
        .navigationTitle("Online Consultation")
        .navigationBarTitleDisplayMode(.inline)
    }
 
    // MARK: - Sections
 
    private var infoCard: some View {
        HStack(spacing: 12) {
            Image(systemName: "video.fill")
                .font(.title2)
                .foregroundStyle(AppTheme.primaryBlue)
            Text("Join your video consultation at your booked time. Calls open right here in the app.")
                .font(.footnote)
                .foregroundStyle(.secondary)
            Spacer(minLength: 0)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 20))
    }
 
    private var emptyState: some View {
        VStack(spacing: 8) {
            Image(systemName: "calendar.badge.plus")
                .font(.largeTitle)
                .foregroundStyle(.secondary)
            Text("No confirmed appointments")
                .font(.headline)
            Text("Book a doctor appointment from Home, then come back here to start your video call.")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(24)
        .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 20))
    }
 
    private func consultationCard(_ appointment: Appointment) -> some View {
        let room = JitsiCall.roomName(from: "\(appointment.id)")
 
        return VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                Image(systemName: "stethoscope")
                    .foregroundStyle(AppTheme.primaryBlue)
                    .frame(width: 28)
 
                VStack(alignment: .leading, spacing: 2) {
                    Text(appointment.doctorName)
                        .font(.headline)
                    Text("\(appointment.displayDate), \(SlotFormatter.display(appointment.slot))")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
            }
 
            JitsiCallButton(roomID: "\(appointment.id)") {
                Label("Join video call", systemImage: "video.fill")
                    .font(.subheadline.bold())
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .foregroundStyle(.white)
                    .background(AppTheme.brandGradient, in: RoundedRectangle(cornerRadius: 14))
            }
 
            if let link = JitsiCall.webURL(room: room) {
                ShareLink(item: link) {
                    Label("Share call link", systemImage: "square.and.arrow.up")
                        .font(.footnote)
                }
            }
        }
        .padding(16)
        .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 20))
        .shadow(color: .black.opacity(0.06), radius: 8, y: 4)
    }
}
 
#Preview {
    NavigationStack {
        OnlineConsultationView()
            .environment(AppointmentStore())
    }
}
