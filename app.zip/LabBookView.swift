import SwiftUI

struct LabBookView: View {
    let test: LabTest

    @Environment(LabBookingStore.self) private var store

    @State private var selectedDate: Date = LabBookView.earliestDate
    @State private var showConfirm = false
    @State private var showResult = false
    @State private var resultTitle = ""
    @State private var resultMessage = ""

    // Booking is allowed from tomorrow up to 30 days ahead
    private static var earliestDate: Date {
        let tomorrow = Calendar.current.date(byAdding: .day, value: 1, to: Date()) ?? Date()
        return Calendar.current.startOfDay(for: tomorrow)
    }

    private static var latestDate: Date {
        Calendar.current.date(byAdding: .day, value: 30, to: earliestDate) ?? earliestDate
    }

    private var dateKey: String {
        AppointmentStore.dateKey(for: selectedDate)
    }

    private var alreadyBooked: Bool {
        store.isBooked(testID: test.id, dateKey: dateKey)
    }

    private var confirmText: String {
        let date = selectedDate.formatted(date: .abbreviated, time: .omitted)
        return "\(test.name)\n\(date)\n\(test.priceText)"
    }

    var body: some View {
        ZStack {
            AppTheme.background.ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    header
                    dateSection
                    bookButton
                    note
                }
                .padding(16)
            }
        }
        .navigationTitle("Book Lab Test")
        .navigationBarTitleDisplayMode(.inline)
        .alert("Confirm booking?", isPresented: $showConfirm) {
            Button("Confirm") { book() }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text(confirmText)
        }
        .alert(resultTitle, isPresented: $showResult) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(resultMessage)
        }
    }

    // MARK: - Sections

    private var header: some View {
        HStack(spacing: 14) {
            Image(systemName: "testtube.2")
                .font(.title)
                .foregroundStyle(.white)
                .frame(width: 64, height: 64)
                .background(AppTheme.brandGradient, in: Circle())

            VStack(alignment: .leading, spacing: 4) {
                Text(test.name)
                    .font(.title3.bold())
                Text(test.description)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(test.priceText)
                    .font(.subheadline.bold())
                    .foregroundStyle(AppTheme.teal)
            }
            Spacer()
        }
        .padding(16)
        .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 20))
        .accessibilityElement(children: .combine)
    }

    private var dateSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Select date")
                .font(.title3.bold())

            DatePicker(
                "Select date",
                selection: $selectedDate,
                in: Self.earliestDate...Self.latestDate,
                displayedComponents: .date
            )
            .datePickerStyle(.graphical)
            .labelsHidden()
            .padding(8)
            .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 20))

            if alreadyBooked {
                Label("You already have this test booked on this date.",
                      systemImage: "info.circle.fill")
                    .font(.footnote)
                    .foregroundStyle(.orange)
            }
        }
    }

    private var bookButton: some View {
        Button {
            showConfirm = true
        } label: {
            Text("Book Test")
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(alreadyBooked ? Color.gray.opacity(0.4) : AppTheme.primaryBlue,
                            in: RoundedRectangle(cornerRadius: 16))
                .foregroundStyle(.white)
        }
        .disabled(alreadyBooked)
    }

    private var note: some View {
        Text("Demo mode: this booking is saved on this phone only. No sample is collected and nothing is sent to any lab. VitalDesk does not give medical advice.")
            .font(.caption)
            .foregroundStyle(.secondary)
            .frame(maxWidth: .infinity, alignment: .center)
            .multilineTextAlignment(.center)
    }

    // MARK: - Actions

    private func book() {
        switch store.book(test: test, date: selectedDate) {
        case .success:
            resultTitle = "Test Booked"
            resultMessage = "Saved in demo mode. See it in My Bookings (top right of the Lab Tests screen)."
        case .failure(let error):
            resultTitle = "Could not book"
            resultMessage = error.localizedDescription
        }
        showResult = true
    }
}

#Preview {
    NavigationStack {
        LabBookView(test: SampleLabTests.all[0])
    }
    .environment(LabBookingStore())
}
