import Foundation

struct AuthUser: Identifiable, Equatable, Codable {
    let id: String
    let name: String
    let email: String
}

enum AuthError: LocalizedError {
    case invalidCredentials
    case emailAlreadyUsed

    var errorDescription: String? {
        switch self {
        case .invalidCredentials:
            return "Incorrect email or password."
        case .emailAlreadyUsed:
            return "An account with this email already exists."
        }
    }
}

protocol AuthService {
    func login(email: String, password: String) async throws -> AuthUser
    func register(name: String, email: String, password: String) async throws -> AuthUser
    func restoreSession() -> AuthUser?
    func logout()
}
