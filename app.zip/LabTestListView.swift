import SwiftUI

struct LabTestListView: View {
    @Environment(LabBookingStore.self) private var store
    @State private var searchText = ""

    private var tests: [LabTest] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !query.isEmpty else { return SampleLabTests.all }
        return SampleLabTests.all.filter { $0.name.lowercased().contains(query) }
    }

    var body: some View {
        ZStack {
            AppTheme.background.ignoresSafeArea()

            ScrollView {
                VStack(spacing: 14) {
                    demoBanner
                    SearchBar(text: $searchText, placeholder: "Search lab tests")

                    if tests.isEmpty {
                        ContentUnavailableView.search(text: searchText)
                    } else {
                        ForEach(tests) { test in
                            NavigationLink {
                                LabBookView(test: test)
                            } label: {
                                LabTestRow(test: test)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
                .padding(16)
            }
        }
        .navigationTitle("Lab Tests")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                NavigationLink {
                    MyLabBookingsView()
                } label: {
                    Image(systemName: "list.clipboard.fill")
                        .overlay(alignment: .topTrailing) {
                            if store.activeCount > 0 {
                                Text("\(store.activeCount)")
                                    .font(.caption2.bold())
                                    .foregroundStyle(.white)
                                    .padding(4)
                                    .background(AppTheme.emergency, in: Circle())
                                    .offset(x: 10, y: -10)
                            }
                        }
                }
                .accessibilityLabel("My lab bookings, \(store.activeCount) active")
            }
        }
    }

    private var demoBanner: some View {
        Label("Sample tests for testing only. Prices are not real. Bookings are saved on this phone only and are not sent to any lab.",
              systemImage: "exclamationmark.triangle.fill")
            .font(.caption)
            .foregroundStyle(.orange)
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.orange.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
    }
}

private struct LabTestRow: View {
    let test: LabTest

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: "testtube.2")
                .font(.title3)
                .foregroundStyle(Color.indigo)
                .frame(width: 48, height: 48)
                .background(Color.indigo.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))

            VStack(alignment: .leading, spacing: 4) {
                Text(test.name)
                    .font(.headline)
                    .foregroundStyle(.primary)
                    .multilineTextAlignment(.leading)
                Text(test.description)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(test.priceText)
                    .font(.subheadline.bold())
                    .foregroundStyle(AppTheme.teal)
            }

            Spacer()

            Image(systemName: "chevron.right")
                .font(.footnote.bold())
                .foregroundStyle(.secondary)
        }
        .padding(14)
        .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 20))
        .shadow(color: .black.opacity(0.06), radius: 8, y: 4)
        .accessibilityElement(children: .combine)
    }
}

#Preview {
    NavigationStack {
        LabTestListView()
    }
    .environment(LabBookingStore())
}
