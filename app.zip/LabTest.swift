import Foundation

struct LabTest: Identifiable, Hashable {
    let id: String
    let name: String
    let description: String
    let price: Double

    var priceText: String {
        price.formatted(.currency(code: "INR"))
    }
}

struct LabBooking: Identifiable, Codable, Hashable {
    enum Status: String, Codable {
        case booked
        case cancelled
    }

    let id: UUID
    let testID: String
    let testName: String
    let price: Double
    /// Date as text, e.g. "2026-10-15"
    let dateKey: String
    var status: Status
    let createdAt: Date

    var priceText: String {
        price.formatted(.currency(code: "INR"))
    }

    var displayDate: String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        guard let date = formatter.date(from: dateKey) else { return dateKey }
        return date.formatted(date: .abbreviated, time: .omitted)
    }
}
