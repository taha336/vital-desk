import SwiftUI

struct MyLabBookingsView: View {
    @Environment(LabBookingStore.self) private var store
    @State private var bookingToCancel: LabBooking?

    var body: some View {
        ZStack {
            AppTheme.background.ignoresSafeArea()

            if store.bookings.isEmpty {
                ContentUnavailableView(
                    "No lab bookings yet",
                    systemImage: "testtube.2",
                    description: Text("Book a test from the Lab Tests screen.")
                )
            } else {
                ScrollView {
                    VStack(spacing: 12) {
                        ForEach(store.sortedBookings) { booking in
                            card(booking)
                        }
                    }
                    .padding(16)
                }
            }
        }
        .navigationTitle("My Lab Bookings")
        .navigationBarTitleDisplayMode(.inline)
        .alert(
            "Cancel booking?",
            isPresented: Binding(
                get: { bookingToCancel != nil },
                set: { if !$0 { bookingToCancel = nil } }
            ),
            presenting: bookingToCancel
        ) { booking in
            Button("Yes, cancel", role: .destructive) {
                store.cancel(booking)
            }
            Button("Keep", role: .cancel) {}
        } message: { booking in
            Text("\(booking.testName)\n\(booking.displayDate)")
        }
    }

    private func card(_ booking: LabBooking) -> some View {
        let isActive = booking.status == .booked

        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(booking.testName)
                    .font(.headline)
                Spacer()
                Text(isActive ? "Booked" : "Cancelled")
                    .font(.caption.bold())
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background((isActive ? AppTheme.teal : Color.gray).opacity(0.15), in: Capsule())
                    .foregroundStyle(isActive ? AppTheme.teal : Color.gray)
            }

            Label(booking.displayDate, systemImage: "calendar")
                .font(.subheadline)

            Text(booking.priceText)
                .font(.subheadline.bold())
                .foregroundStyle(AppTheme.teal)

            if isActive {
                Button(role: .destructive) {
                    bookingToCancel = booking
                } label: {
                    Label("Cancel booking", systemImage: "xmark.circle")
                        .font(.subheadline)
                }
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 20))
        .shadow(color: .black.opacity(0.06), radius: 8, y: 4)
        .opacity(isActive ? 1 : 0.7)
    }
}

#Preview {
    NavigationStack {
        MyLabBookingsView()
    }
    .environment(LabBookingStore())
}
