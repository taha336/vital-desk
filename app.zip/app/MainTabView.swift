import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem { Label("Home", systemImage: "house.fill") }

            MyAppointmentsView()
                .tabItem { Label("Appointments", systemImage: "calendar") }

            NavigationStack {
                MedicineListView()
            }
            .tabItem { Label("Medicines", systemImage: "pills.fill") }

            ProfileView()
                .tabItem { Label("Profile", systemImage: "person.crop.circle.fill") }
        }
        .tint(AppTheme.primaryBlue)
    }
}

#Preview {
    MainTabView()
        .environment(AppointmentStore())
        .environment(CartStore())
}
