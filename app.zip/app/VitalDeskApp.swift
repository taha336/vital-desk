import SwiftUI

@main
struct VitalDeskApp: App {
    @State private var showSplash = true
    @State private var appointmentStore = AppointmentStore()
    @State private var cartStore = CartStore()
    @State private var labStore = LabBookingStore()
    @State private var authViewModel = AuthViewModel()

    var body: some Scene {
        WindowGroup {
            ZStack {
                RootView()

                if showSplash {
                    SplashView()
                        .transition(.opacity)
                        .zIndex(1)
                }
            }
            .environment(appointmentStore)
            .environment(cartStore)
            .environment(labStore)
            .environment(authViewModel)
            .task {
                try? await Task.sleep(for: .seconds(2))
                withAnimation(.easeOut(duration: 0.5)) {
                    showSplash = false
                }
            }
        }
    }
}
