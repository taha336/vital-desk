import SwiftUI

struct ServiceCard: View {
    let service: ServiceType

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Image(systemName: service.systemImage)
                .font(.title2)
                .foregroundStyle(service.tint)
                .frame(width: 48, height: 48)
                .background(service.tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))

            VStack(alignment: .leading, spacing: 4) {
                Text(service.title)
                    .font(.headline)
                    .foregroundStyle(.primary)
                    .multilineTextAlignment(.leading)
                Text(service.subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.leading)
            }
        }
        .frame(maxWidth: .infinity, minHeight: 130, alignment: .topLeading)
        .padding(16)
        .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 20))
        .shadow(color: .black.opacity(0.06), radius: 8, y: 4)
        .accessibilityElement(children: .combine)
    }
}
