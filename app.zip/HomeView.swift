import SwiftUI
 
struct HomeView: View {
    @Environment(AppointmentStore.self) private var store
    @Environment(AuthViewModel.self) private var auth
 
    @State private var viewModel = HomeViewModel()
    @State private var call: CallSession?
 
    private let columns = [
        GridItem(.flexible(), spacing: 16),
        GridItem(.flexible(), spacing: 16)
    ]
 
    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.background.ignoresSafeArea()
 
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        welcomeCard
                        SearchBar(text: $viewModel.searchText)
                        servicesSection
                        emergencyBanner
                        disclaimer
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                }
            }
            .navigationTitle("VITALDESK")
            .navigationBarTitleDisplayMode(.inline)
            .navigationDestination(for: ServiceType.self) { service in
                switch service {
                case .appointments:
                    DoctorListView()
                case .medicines:
                    MedicineListView()
                case .labTests:
                    LabTestListView()
                case .consultation:
                    OnlineConsultationView()
                }
            }
            .fullScreenCover(item: $call) { session in
                JitsiCallScreen(room: session.room, displayName: auth.currentUser?.name)
            }
        }
    }
 
    // MARK: - Sections
 
    private var welcomeCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(viewModel.greeting)
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.85))
            Text("Welcome to VitalDesk")
                .font(.title.bold())
                .foregroundStyle(.white)
            Text("How can we help with your health today?")
                .font(.footnote)
                .foregroundStyle(.white.opacity(0.9))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(20)
        .background(AppTheme.brandGradient, in: RoundedRectangle(cornerRadius: 24))
        .accessibilityElement(children: .combine)
    }
 
    @ViewBuilder
    private var servicesSection: some View {
        Text("Our Services")
            .font(.title3.bold())
 
        if viewModel.filteredServices.isEmpty {
            ContentUnavailableView.search(text: viewModel.searchText)
                .frame(maxWidth: .infinity)
        } else {
            LazyVGrid(columns: columns, spacing: 16) {
                ForEach(viewModel.filteredServices) { service in
                    if service == .consultation {
                        Button {
                            startConsultation()
                        } label: {
                            ServiceCard(service: service)
                        }
                        .buttonStyle(.plain)
                    } else {
                        NavigationLink(value: service) {
                            ServiceCard(service: service)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .animation(.easeInOut(duration: 0.25), value: viewModel.filteredServices)
        }
    }
 
    private var emergencyBanner: some View {
        VStack(alignment: .leading, spacing: 10) {
            Label("Emergency", systemImage: "cross.fill")
                .font(.headline)
                .foregroundStyle(AppTheme.emergency)
 
            Text("In a medical emergency, call your local emergency number immediately. In India, 112 is the national emergency number and 108 is the ambulance service in many states. Numbers may vary by region, so please verify for your area.")
                .font(.footnote)
                .foregroundStyle(.secondary)
 
            HStack(spacing: 12) {
                emergencyCallButton(title: "Call 112", number: "112")
                emergencyCallButton(title: "Call 108", number: "108")
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppTheme.emergency.opacity(0.10), in: RoundedRectangle(cornerRadius: 20))
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(AppTheme.emergency.opacity(0.35), lineWidth: 1)
        )
    }
 
    private func emergencyCallButton(title: String, number: String) -> some View {
        Link(destination: URL(string: "tel:\(number)")!) {
            Label(title, systemImage: "phone.fill")
                .font(.subheadline.bold())
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .background(AppTheme.emergency, in: RoundedRectangle(cornerRadius: 14))
                .foregroundStyle(.white)
        }
    }
 
    private var disclaimer: some View {
        Text("VitalDesk does not provide medical advice, diagnosis or prescriptions. Always consult a qualified doctor.")
            .font(.caption2)
            .foregroundStyle(.secondary)
            .frame(maxWidth: .infinity, alignment: .center)
            .multilineTextAlignment(.center)
            .padding(.bottom, 8)
    }
 
    // MARK: - Video consultation
 
    /// Starts the Jitsi video call right away.
    /// Uses the next confirmed appointment's room; otherwise the user's own room.
    private func startConsultation() {
        let id: String
        if let next = store.sortedAppointments.first(where: { $0.status == .confirmed }) {
            id = "\(next.id)"
        } else {
            id = auth.currentUser?.id ?? UUID().uuidString
        }
        call = CallSession(room: JitsiCall.roomName(from: id))
    }
}
 
#Preview {
    HomeView()
        .environment(AppointmentStore())
        .environment(CartStore())
        .environment(LabBookingStore())
        .environment(AuthViewModel())
}
