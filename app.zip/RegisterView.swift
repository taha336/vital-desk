import SwiftUI
 
struct RegisterView: View {
    @Environment(AuthViewModel.self) private var auth
    @Environment(\.dismiss) private var dismiss
 
    @State private var name = ""
    @State private var email = ""
    @State private var password = ""
    @State private var confirm = ""
 
    private var cleanedName: String {
        name.trimmingCharacters(in: .whitespacesAndNewlines)
    }
 
    private var cleanedEmail: String {
        email.trimmingCharacters(in: .whitespacesAndNewlines)
    }
 
    private var nameError: String? {
        name.isEmpty || !cleanedName.isEmpty ? nil : "Please enter your name."
    }
 
    private var emailError: String? {
        if email.isEmpty { return nil }
        let ok = cleanedEmail.range(of: #"^[^@\s]+@[^@\s]+\.[^@\s]+$"#, options: .regularExpression) != nil
        return ok ? nil : "Please enter a valid email."
    }
 
    private var passwordError: String? {
        if password.isEmpty { return nil }
        return password.count >= 6 ? nil : "Password must be at least 6 characters."
    }
 
    private var confirmError: String? {
        if confirm.isEmpty { return nil }
        return confirm == password ? nil : "Passwords do not match."
    }
 
    private var canSubmit: Bool {
        !cleanedName.isEmpty
        && !cleanedEmail.isEmpty && emailError == nil
        && password.count >= 6
        && confirm == password
        && !auth.isLoading
    }
 
    var body: some View {
        ZStack {
            AppTheme.background.ignoresSafeArea()
 
            ScrollView {
                VStack(spacing: 14) {
                    field {
                        TextField("Full name", text: $name)
                            .textContentType(.name)
                            .textInputAutocapitalization(.words)
                    }
                    errorText(nameError)
 
                    field {
                        TextField("Email", text: $email)
                            .keyboardType(.emailAddress)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .textContentType(.emailAddress)
                    }
                    errorText(emailError)
 
                    field {
                        SecureField("Password (min 6 characters)", text: $password)
                            .textContentType(.newPassword)
                    }
                    errorText(passwordError)
 
                    field {
                        SecureField("Confirm password", text: $confirm)
                            .textContentType(.newPassword)
                    }
                    errorText(confirmError)
 
                    errorText(auth.errorMessage)
 
                    Button {
                        Task {
                            let ok = await auth.register(
                                name: cleanedName,
                                email: cleanedEmail,
                                password: password
                            )
                            if ok { dismiss() }
                        }
                    } label: {
                        Group {
                            if auth.isLoading {
                                ProgressView().tint(.white)
                            } else {
                                Text("Create account").bold()
                            }
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .foregroundStyle(.white)
                        .background(AppTheme.brandGradient, in: RoundedRectangle(cornerRadius: 14))
                    }
                    .disabled(!canSubmit)
                    .opacity(canSubmit ? 1 : 0.5)
                    .padding(.top, 8)
                }
                .padding(20)
            }
        }
        .navigationTitle("Create account")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { auth.clearError() }
    }
 
    // MARK: - Helpers
 
    private func field<Content: View>(@ViewBuilder _ content: () -> Content) -> some View {
        content()
            .padding(14)
            .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 14))
    }
 
    @ViewBuilder
    private func errorText(_ message: String?) -> some View {
        if let message {
            Text(message)
                .font(.footnote)
                .foregroundStyle(.red)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}
 
#Preview {
    NavigationStack {
        RegisterView()
            .environment(AuthViewModel())
    }
}
