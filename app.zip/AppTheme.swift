import SwiftUI

extension Color {
    /// Create a colour from a hex number, e.g. Color(hex: 0x1565C0)
    init(hex: UInt32) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255,
            opacity: 1
        )
    }

    /// A colour that changes automatically in light / dark mode
    init(light: Color, dark: Color) {
        self.init(uiColor: UIColor { traits in
            traits.userInterfaceStyle == .dark ? UIColor(dark) : UIColor(light)
        })
    }
}

enum AppTheme {
    static let primaryBlue = Color(light: Color(hex: 0x1565C0), dark: Color(hex: 0x64B5F6))
    static let teal = Color(light: Color(hex: 0x00897B), dark: Color(hex: 0x4DB6AC))
    static let background = Color(light: Color(hex: 0xF4F8FB), dark: Color(hex: 0x0E1621))
    static let card = Color(light: .white, dark: Color(hex: 0x1A2533))
    static let emergency = Color(light: Color(hex: 0xD32F2F), dark: Color(hex: 0xEF5350))

    static let brandGradient = LinearGradient(
        colors: [Color(hex: 0x1565C0), Color(hex: 0x00897B)],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
}
