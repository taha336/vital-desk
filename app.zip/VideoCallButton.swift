import SwiftUI
import WebKit
 
// MARK: - Settings
 
enum JitsiCall {
    /// Jitsi server used for calls.
    /// - meet.jit.si now asks the first person to log in (Google/GitHub) before a
    ///   meeting can start, which does not work well inside an app.
    /// - meet.ffmuc.net is a community-run Jitsi server. Change this one line to
    ///   switch servers (for production, use your own Jitsi server).
    static let server = "meet.ffmuc.net"
 
    /// Room names are part of the link: anyone who knows the name can join.
    /// Use something hard to guess (e.g. a UUID).
    static func roomName(from id: String) -> String {
        let clean = id.filter { $0.isLetter || $0.isNumber }
        return "VitalDesk" + clean
    }
 
    /// Plain link you can share (opens in any browser).
    static func webURL(room: String) -> URL? {
        URL(string: "https://\(server)/\(room)")
    }
 
    /// Link used inside the app's web view.
    static func embedURL(room: String, displayName: String?) -> URL? {
        var options = ["config.disableDeepLinking=true"]
 
        if let name = displayName?.trimmingCharacters(in: .whitespacesAndNewlines),
           !name.isEmpty,
           let encoded = "\"\(name)\"".addingPercentEncoding(withAllowedCharacters: .alphanumerics) {
            options.append("userInfo.displayName=\(encoded)")
        }
 
        return URL(string: "https://\(server)/\(room)#" + options.joined(separator: "&"))
    }
}
 
struct CallSession: Identifiable {
    let id = UUID()
    let room: String
}
 
// MARK: - In-app call screen
 
struct JitsiCallScreen: View {
    let room: String
    var displayName: String? = nil
 
    @Environment(\.dismiss) private var dismiss
 
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Label("Video consultation", systemImage: "video.fill")
                    .font(.subheadline.bold())
                    .foregroundStyle(.white)
                Spacer()
                Button {
                    dismiss()
                } label: {
                    Text("Leave")
                        .font(.subheadline.bold())
                        .padding(.horizontal, 14)
                        .padding(.vertical, 6)
                        .background(Color.red, in: Capsule())
                        .foregroundStyle(.white)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(Color.black)
 
            if let url = JitsiCall.embedURL(room: room, displayName: displayName) {
                JitsiWebView(url: url)
            } else {
                Spacer()
                Text("Could not start the call.")
                    .foregroundStyle(.white)
                Spacer()
            }
        }
        .background(Color.black.ignoresSafeArea())
    }
}
 
struct JitsiWebView: UIViewRepresentable {
    let url: URL
 
    func makeCoordinator() -> Coordinator { Coordinator() }
 
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
 
        let web = WKWebView(frame: .zero, configuration: config)
        // Look like Safari so Jitsi treats this as a supported browser.
        web.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
        web.uiDelegate = context.coordinator
        web.isOpaque = false
        web.backgroundColor = .black
        web.load(URLRequest(url: url))
        return web
    }
 
    func updateUIView(_ uiView: WKWebView, context: Context) {}
 
    // Stops camera and mic when the screen closes.
    static func dismantleUIView(_ uiView: WKWebView, coordinator: Coordinator) {
        if let blank = URL(string: "about:blank") {
            uiView.load(URLRequest(url: blank))
        }
    }
 
    final class Coordinator: NSObject, WKUIDelegate {
        // Lets the Jitsi page use the camera and microphone.
        func webView(
            _ webView: WKWebView,
            requestMediaCapturePermissionFor origin: WKSecurityOrigin,
            initiatedByFrame frame: WKFrameInfo,
            type: WKMediaCaptureType,
            decisionHandler: @escaping (WKPermissionDecision) -> Void
        ) {
            decisionHandler(origin.host == JitsiCall.server ? .grant : .deny)
        }
    }
}
 
// MARK: - Buttons
 
/// Wrap any label. Tapping it starts the video call inside the app.
///
///     JitsiCallButton(roomID: "\(appointment.id)") {
///         Label("Call", systemImage: "video.fill")
///     }
struct JitsiCallButton<Label: View>: View {
    let roomID: String
    var displayName: String? = nil
    @ViewBuilder var label: () -> Label
 
    @State private var session: CallSession?
 
    var body: some View {
        Button {
            session = CallSession(room: JitsiCall.roomName(from: roomID))
        } label: {
            label()
        }
        .fullScreenCover(item: $session) { session in
            JitsiCallScreen(room: session.room, displayName: displayName)
        }
    }
}
 
/// Ready-made button.  Usage: VideoCallButton(roomID: "\(appointment.id)")
struct VideoCallButton: View {
    let roomID: String
    var title: String = "Start video call"
    var displayName: String? = nil
 
    var body: some View {
        JitsiCallButton(roomID: roomID, displayName: displayName) {
            Label(title, systemImage: "video.fill")
                .font(.subheadline.bold())
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .foregroundStyle(.white)
                .background(AppTheme.brandGradient, in: RoundedRectangle(cornerRadius: 14))
        }
    }
}
 
#Preview {
    VideoCallButton(roomID: UUID().uuidString)
        .padding()
}
 
