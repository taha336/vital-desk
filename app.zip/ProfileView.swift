import SwiftUI

struct ProfileView: View {
    @Environment(AppointmentStore.self) private var store
    @Environment(AuthViewModel.self) private var auth

    // Profile details are saved locally on this device.
    @AppStorage("profile_name") private var name = ""
    @AppStorage("profile_phone") private var phone = ""
    @AppStorage("profile_email") private var email = ""

    @State private var showEditor = false
    @State private var showClearConfirm = false
    @State private var showPrivacy = false
    @State private var showSignOutConfirm = false

    private var shownName: String {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmed.isEmpty { return trimmed }
        return auth.currentUser?.name ?? ""
    }

    private var shownEmail: String {
        email.isEmpty ? (auth.currentUser?.email ?? "") : email
    }

    private var displayName: String {
        shownName.isEmpty ? "Guest" : shownName
    }

    private var initials: String {
        let parts = displayName.split(separator: " ").prefix(2)
        let result = parts.compactMap(\.first).map(String.init).joined()
        return result.isEmpty ? "G" : result.uppercased()
    }

    private var confirmedCount: Int {
        store.appointments.filter { $0.status == .confirmed }.count
    }

    private var cancelledCount: Int {
        store.appointments.filter { $0.status == .cancelled }.count
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.background.ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 20) {
                        headerCard
                        statsRow
                        personalInfoCard
                        appointmentHistoryCard
                        settingsCard
                        footer
                    }
                    .padding(16)
                }
            }
            .navigationTitle("Profile")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Edit") {
                        showEditor = true
                    }
                }
            }
            .sheet(isPresented: $showEditor) {
                EditProfileSheet(name: $name, phone: $phone, email: $email)
            }
            .alert("Delete all appointments?", isPresented: $showClearConfirm) {
                Button("Delete", role: .destructive) {
                    store.clearAll()
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("This removes every appointment saved in the app.")
            }
            .alert("Privacy", isPresented: $showPrivacy) {
                Button("OK", role: .cancel) {}
            } message: {
                Text("This is a demo build: your account and profile details are saved only on this phone and are not sent to any server.")
            }
            .alert("Sign out?", isPresented: $showSignOutConfirm) {
                Button("Sign out", role: .destructive) {
                    auth.logout()
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("You will need to log in again to use VitalDesk.")
            }
        }
    }

    // MARK: - Sections

    private var headerCard: some View {
        VStack(spacing: 10) {
            Text(initials)
                .font(.system(size: 34, weight: .bold, design: .rounded))
                .foregroundStyle(Color(hex: 0x1565C0))
                .frame(width: 88, height: 88)
                .background(Color.white, in: Circle())
                .overlay(Circle().stroke(Color.white.opacity(0.5), lineWidth: 4))

            Text(displayName)
                .font(.title2.bold())
                .foregroundStyle(.white)

            Text(shownEmail.isEmpty ? "Patient" : shownEmail)
                .font(.footnote)
                .foregroundStyle(.white.opacity(0.85))
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 24)
        .background(AppTheme.brandGradient, in: RoundedRectangle(cornerRadius: 28))
        .accessibilityElement(children: .combine)
    }

    private var statsRow: some View {
        HStack(spacing: 12) {
            StatTile(
                value: confirmedCount,
                title: "Confirmed",
                systemImage: "calendar.badge.clock",
                tint: AppTheme.primaryBlue
            )
            StatTile(
                value: cancelledCount,
                title: "Cancelled",
                systemImage: "xmark.circle",
                tint: AppTheme.emergency
            )
            StatTile(
                value: store.appointments.count,
                title: "Total",
                systemImage: "list.bullet.rectangle",
                tint: AppTheme.teal
            )
        }
    }

    private var personalInfoCard: some View {
        sectionCard("Personal information") {
            infoRow("Full name", value: shownName, icon: "person.fill")
            Divider()
            infoRow("Phone", value: phone, icon: "phone.fill")
            Divider()
            infoRow("Email", value: shownEmail, icon: "envelope.fill")
        }
    }

    private var appointmentHistoryCard: some View {
        sectionCard("Appointment history") {
            if store.appointments.isEmpty {
                Text("No appointments yet. Book one from Home.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(Array(store.sortedAppointments.prefix(3))) { appointment in
                    historyRow(appointment)
                }

                if store.appointments.count > 3 {
                    Text("Showing 3 of \(store.appointments.count). See all in the Appointments tab.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private var settingsCard: some View {
        sectionCard("Settings and account") {
            Button {
                showPrivacy = true
            } label: {
                settingsLabel(
                    "Privacy and data",
                    icon: "lock.shield.fill",
                    tint: AppTheme.primaryBlue
                )
            }
            .buttonStyle(.plain)

            Divider()

            Button(role: .destructive) {
                showClearConfirm = true
            } label: {
                settingsLabel(
                    "Delete my appointments",
                    icon: "trash.fill",
                    tint: AppTheme.emergency
                )
            }
            .buttonStyle(.plain)
            .disabled(store.appointments.isEmpty)

            Divider()

            Button(role: .destructive) {
                showSignOutConfirm = true
            } label: {
                settingsLabel(
                    "Sign out",
                    icon: "rectangle.portrait.and.arrow.right",
                    tint: AppTheme.emergency
                )
            }
            .buttonStyle(.plain)
        }
    }

    private var footer: some View {
        VStack(spacing: 4) {
            Text("VitalDesk")
                .font(.caption.bold())
            Text("VitalDesk does not provide medical advice, diagnosis or prescriptions.")
                .font(.caption2)
                .multilineTextAlignment(.center)
        }
        .foregroundStyle(.secondary)
        .padding(.bottom, 8)
    }

    // MARK: - Helpers

    private func sectionCard<Content: View>(
        _ title: String,
        @ViewBuilder content: () -> Content
    ) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(title).font(.headline)
            content()
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 20))
        .shadow(color: .black.opacity(0.06), radius: 8, y: 4)
    }

    private func infoRow(_ title: String, value: String, icon: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(AppTheme.teal)
                .frame(width: 28)

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(value.isEmpty ? "Not added" : value)
                    .font(.subheadline)
            }

            Spacer()
        }
        .accessibilityElement(children: .combine)
    }

    private func historyRow(_ appointment: Appointment) -> some View {
        let isConfirmed = appointment.status == .confirmed

        return HStack(spacing: 12) {
            Image(systemName: "stethoscope")
                .foregroundStyle(AppTheme.primaryBlue)
                .frame(width: 28)

            VStack(alignment: .leading, spacing: 2) {
                Text(appointment.doctorName)
                    .font(.subheadline.bold())
                Text("\(appointment.displayDate), \(SlotFormatter.display(appointment.slot))")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Text(isConfirmed ? "Confirmed" : "Cancelled")
                .font(.caption2.bold())
                .padding(.horizontal, 8)
                .padding(.vertical, 3)
                .background(
                    (isConfirmed ? AppTheme.teal : Color.gray).opacity(0.15),
                    in: Capsule()
                )
                .foregroundStyle(isConfirmed ? AppTheme.teal : Color.gray)
        }
        .accessibilityElement(children: .combine)
    }

    private func settingsLabel(_ title: String, icon: String, tint: Color) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(tint)
                .frame(width: 28)
            Text(title)
                .font(.subheadline)
                .foregroundStyle(.primary)
            Spacer()
        }
    }
}

// MARK: - Stat tile

private struct StatTile: View {
    let value: Int
    let title: String
    let systemImage: String
    let tint: Color

    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: systemImage)
                .foregroundStyle(tint)
            Text("\(value)")
                .font(.title2.bold())
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 18))
        .shadow(color: .black.opacity(0.06), radius: 8, y: 4)
        .accessibilityElement(children: .combine)
    }
}

// MARK: - Edit sheet

private struct EditProfileSheet: View {
    @Binding var name: String
    @Binding var phone: String
    @Binding var email: String

    @Environment(\.dismiss) private var dismiss

    @State private var draftName = ""
    @State private var draftPhone = ""
    @State private var draftEmail = ""

    private var cleanedName: String {
        draftName.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var nameError: String? {
        cleanedName.isEmpty ? "Please enter your name." : nil
    }

    private var phoneError: String? {
        if draftPhone.isEmpty { return nil }
        let digits = draftPhone.filter(\.isNumber)
        return digits.count == 10 ? nil : "Phone number must be 10 digits."
    }

    private var emailError: String? {
        if draftEmail.isEmpty { return nil }
        let pattern = #"^[^@\s]+@[^@\s]+\.[^@\s]+$"#
        return draftEmail.range(of: pattern, options: .regularExpression) != nil
            ? nil
            : "Please enter a valid email."
    }

    private var isValid: Bool {
        nameError == nil && phoneError == nil && emailError == nil
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Personal details") {
                    TextField("Full name", text: $draftName)
                        .textContentType(.name)
                        .textInputAutocapitalization(.words)

                    if let nameError {
                        Text(nameError)
                            .font(.caption)
                            .foregroundStyle(.red)
                    }

                    TextField("Phone (10 digits)", text: $draftPhone)
                        .keyboardType(.numberPad)
                        .textContentType(.telephoneNumber)

                    if let phoneError {
                        Text(phoneError)
                            .font(.caption)
                            .foregroundStyle(.red)
                    }

                    TextField("Email", text: $draftEmail)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .textContentType(.emailAddress)

                    if let emailError {
                        Text(emailError)
                            .font(.caption)
                            .foregroundStyle(.red)
                    }
                }

                Section {
                    Text("Saved on this phone only.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Edit Profile")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { save() }
                        .disabled(!isValid)
                }
            }
            .onAppear {
                draftName = name
                draftPhone = phone
                draftEmail = email
            }
        }
    }

    private func save() {
        name = cleanedName
        phone = draftPhone.filter(\.isNumber)
        email = draftEmail.trimmingCharacters(in: .whitespacesAndNewlines)
        dismiss()
    }
}

#Preview {
    ProfileView()
        .environment(AppointmentStore())
        .environment(AuthViewModel())
}
