import Foundation
import Observation

@Observable
final class CartStore {
    struct Line: Identifiable, Hashable {
        let medicine: Medicine
        var quantity: Int
        var id: String { medicine.id }
    }

    static let maxQuantity = 10

    private(set) var lines: [Line] = []

    var totalItems: Int {
        lines.reduce(0) { $0 + $1.quantity }
    }

    var totalPrice: Double {
        lines.reduce(0) { $0 + $1.medicine.price * Double($1.quantity) }
    }

    var needsPrescription: Bool {
        lines.contains { $0.medicine.requiresPrescription }
    }

    func quantity(of medicine: Medicine) -> Int {
        lines.first(where: { $0.medicine.id == medicine.id })?.quantity ?? 0
    }

    func add(_ medicine: Medicine) {
        if let index = lines.firstIndex(where: { $0.medicine.id == medicine.id }) {
            if lines[index].quantity < Self.maxQuantity {
                lines[index].quantity += 1
            }
        } else {
            lines.append(Line(medicine: medicine, quantity: 1))
        }
    }

    func decrease(_ medicine: Medicine) {
        guard let index = lines.firstIndex(where: { $0.medicine.id == medicine.id }) else { return }
        if lines[index].quantity > 1 {
            lines[index].quantity -= 1
        } else {
            lines.remove(at: index)
        }
    }

    func remove(_ medicine: Medicine) {
        lines.removeAll { $0.medicine.id == medicine.id }
    }

    func clear() {
        lines.removeAll()
    }
}
