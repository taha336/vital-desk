import Foundation

enum AuthValidator {
    static func nameError(_ name: String) -> String? {
        name.trimmingCharacters(in: .whitespacesAndNewlines).count >= 2
            ? nil : "Please enter your full name."
    }

    static func emailError(_ email: String) -> String? {
        let value = email.trimmingCharacters(in: .whitespacesAndNewlines)
        if value.isEmpty { return "Please enter your email." }
        let pattern = "^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$"
        return value.range(of: pattern, options: .regularExpression) != nil
            ? nil : "Please enter a valid email address."
    }

    static func passwordError(_ password: String) -> String? {
        if password.count < 8 { return "Password must be at least 8 characters." }
        let hasLetter = password.contains { $0.isLetter }
        let hasNumber = password.contains { $0.isNumber }
        return (hasLetter && hasNumber) ? nil : "Password needs at least one letter and one number."
    }

    static func confirmError(_ password: String, _ confirm: String) -> String? {
        password == confirm ? nil : "Passwords do not match."
    }
}
