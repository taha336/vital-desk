import SwiftUI

enum ServiceType: String, CaseIterable, Identifiable, Hashable {
    case appointments
    case medicines
    case labTests
    case consultation

    var id: String { rawValue }

    var title: String {
        switch self {
        case .appointments: return "Doctor Appointments"
        case .medicines: return "Medicines"
        case .labTests: return "Lab Tests"
        case .consultation: return "Online Consultation"
        }
    }

    var subtitle: String {
        switch self {
        case .appointments: return "Book a visit with a doctor"
        case .medicines: return "Order with a valid prescription"
        case .labTests: return "Book tests by date"
        case .consultation: return "Consult from home"
        }
    }

    var systemImage: String {
        switch self {
        case .appointments: return "stethoscope"
        case .medicines: return "pills.fill"
        case .labTests: return "testtube.2"
        case .consultation: return "video.fill"
        }
    }

    var tint: Color {
        switch self {
        case .appointments: return AppTheme.primaryBlue
        case .medicines: return AppTheme.teal
        case .labTests: return Color.indigo
        case .consultation: return Color.cyan
        }
    }

    /// Words used by the search bar
    var searchKeywords: String {
        "\(title) \(subtitle)".lowercased()
    }
}
