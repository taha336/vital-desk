import SwiftUI
 
struct LoginView: View {
    @Environment(AuthViewModel.self) private var auth
 
    @State private var email = ""
    @State private var password = ""
 
    private var cleanedEmail: String {
        email.trimmingCharacters(in: .whitespacesAndNewlines)
    }
 
    private var isEmailValid: Bool {
        cleanedEmail.range(of: #"^[^@\s]+@[^@\s]+\.[^@\s]+$"#, options: .regularExpression) != nil
    }
 
    private var canSubmit: Bool {
        isEmailValid && !password.isEmpty && !auth.isLoading
    }
 
    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.background.ignoresSafeArea()
 
                ScrollView {
                    VStack(spacing: 22) {
                        header
 
                        VStack(spacing: 14) {
                            TextField("Email", text: $email)
                                .keyboardType(.emailAddress)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .textContentType(.emailAddress)
                                .padding(14)
                                .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 14))
 
                            SecureField("Password", text: $password)
                                .textContentType(.password)
                                .padding(14)
                                .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 14))
 
                            if let message = auth.errorMessage {
                                Text(message)
                                    .font(.footnote)
                                    .foregroundStyle(.red)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                        }
 
                        Button {
                            Task { await auth.login(email: cleanedEmail, password: password) }
                        } label: {
                            Group {
                                if auth.isLoading {
                                    ProgressView().tint(.white)
                                } else {
                                    Text("Log in").bold()
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .foregroundStyle(.white)
                            .background(AppTheme.brandGradient, in: RoundedRectangle(cornerRadius: 14))
                        }
                        .disabled(!canSubmit)
                        .opacity(canSubmit ? 1 : 0.5)
 
                        NavigationLink {
                            RegisterView()
                        } label: {
                            Text("New here? Create an account")
                                .font(.subheadline)
                        }
                    }
                    .padding(20)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .onAppear { auth.clearError() }
            .onChange(of: email) { auth.clearError() }
            .onChange(of: password) { auth.clearError() }
        }
    }
 
    private var header: some View {
        VStack(spacing: 10) {
            Image(systemName: "cross.case.fill")
                .font(.system(size: 44))
                .foregroundStyle(.white)
                .frame(width: 88, height: 88)
                .background(AppTheme.brandGradient, in: Circle())
 
            Text("VitalDesk")
                .font(.title.bold())
 
            Text("Log in to book and manage your appointments.")
                .font(.footnote)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(.top, 24)
    }
}
 
#Preview {
    LoginView()
        .environment(AuthViewModel())
}
