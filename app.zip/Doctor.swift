import Foundation

struct Doctor: Identifiable, Hashable, Codable {
    let id: String
    let name: String
    let specialization: String
    let experienceYears: Int
    /// Days the doctor is available. 1 = Sunday, 2 = Monday ... 7 = Saturday
    let availableWeekdays: [Int]
    /// Time slots in 24-hour "HH:mm" format
    let slots: [String]

    var availabilityText: String {
        let symbols = Calendar.current.shortWeekdaySymbols
        let days = availableWeekdays.sorted().compactMap { day -> String? in
            (day >= 1 && day <= symbols.count) ? symbols[day - 1] : nil
        }
        return days.joined(separator: ", ")
    }
}
