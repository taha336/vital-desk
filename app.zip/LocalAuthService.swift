import Foundation
import CryptoKit
 
/// Demo-only auth: accounts are stored in UserDefaults on this device.
/// Not for production (no server, no Keychain).
final class LocalAuthService: AuthService {
    private struct StoredAccount: Codable {
        let user: AuthUser
        let passwordHash: String
    }
 
    private let defaults: UserDefaults
    private let accountsKey = "local_auth_accounts"
    private let sessionKey = "local_auth_session_email"
 
    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
    }
 
    func login(email: String, password: String) async throws -> AuthUser {
        let key = normalized(email)
        guard let account = loadAccounts()[key],
              account.passwordHash == hash(password) else {
            throw AuthError.invalidCredentials
        }
        defaults.set(key, forKey: sessionKey)
        return account.user
    }
 
    func register(name: String, email: String, password: String) async throws -> AuthUser {
        let key = normalized(email)
        var accounts = loadAccounts()
        guard accounts[key] == nil else { throw AuthError.emailAlreadyUsed }
 
        let user = AuthUser(
            id: UUID().uuidString,
            name: name.trimmingCharacters(in: .whitespacesAndNewlines),
            email: key
        )
        accounts[key] = StoredAccount(user: user, passwordHash: hash(password))
        saveAccounts(accounts)
        defaults.set(key, forKey: sessionKey)
        return user
    }
 
    func restoreSession() -> AuthUser? {
        guard let key = defaults.string(forKey: sessionKey) else { return nil }
        return loadAccounts()[key]?.user
    }
 
    func logout() {
        defaults.removeObject(forKey: sessionKey)
    }
 
    // MARK: - Helpers
 
    private func normalized(_ email: String) -> String {
        email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
    }
 
    private func hash(_ password: String) -> String {
        SHA256.hash(data: Data(password.utf8))
            .map { String(format: "%02x", $0) }
            .joined()
    }
 
    private func loadAccounts() -> [String: StoredAccount] {
        guard let data = defaults.data(forKey: accountsKey),
              let decoded = try? JSONDecoder().decode([String: StoredAccount].self, from: data)
        else { return [:] }
        return decoded
    }
 
    private func saveAccounts(_ accounts: [String: StoredAccount]) {
        if let data = try? JSONEncoder().encode(accounts) {
            defaults.set(data, forKey: accountsKey)
        }
    }
}
