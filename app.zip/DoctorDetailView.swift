import SwiftUI

struct DoctorDetailView: View {
    let doctor: Doctor

    @Environment(AppointmentStore.self) private var store

    @State private var selectedDate: Date = DoctorDetailView.earliestDate
    @State private var selectedSlot: String?
    @State private var showConfirm = false
    @State private var showResult = false
    @State private var resultTitle = ""
    @State private var resultMessage = ""

    // Booking is allowed from tomorrow up to 30 days ahead
    private static var earliestDate: Date {
        let tomorrow = Calendar.current.date(byAdding: .day, value: 1, to: Date()) ?? Date()
        return Calendar.current.startOfDay(for: tomorrow)
    }

    private static var latestDate: Date {
        Calendar.current.date(byAdding: .day, value: 30, to: earliestDate) ?? earliestDate
    }

    private var dateKey: String {
        AppointmentStore.dateKey(for: selectedDate)
    }

    private var isAvailableDay: Bool {
        let weekday = Calendar.current.component(.weekday, from: selectedDate)
        return doctor.availableWeekdays.contains(weekday)
    }

    private var confirmText: String {
        let date = selectedDate.formatted(date: .abbreviated, time: .omitted)
        let time = SlotFormatter.display(selectedSlot ?? "")
        return "\(doctor.name)\n\(date) at \(time)"
    }

    var body: some View {
        ZStack {
            AppTheme.background.ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    header
                    dateSection
                    slotsSection
                    confirmButton
                    note
                }
                .padding(16)
            }
        }
        .navigationTitle("Book Appointment")
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of: selectedDate) { _, _ in
            selectedSlot = nil
        }
        .alert("Confirm appointment?", isPresented: $showConfirm) {
            Button("Confirm") { book() }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text(confirmText)
        }
        .alert(resultTitle, isPresented: $showResult) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(resultMessage)
        }
    }

    // MARK: - Sections

    private var header: some View {
        HStack(spacing: 14) {
            Image(systemName: "person.fill")
                .font(.title)
                .foregroundStyle(.white)
                .frame(width: 64, height: 64)
                .background(AppTheme.brandGradient, in: Circle())

            VStack(alignment: .leading, spacing: 4) {
                Text(doctor.name)
                    .font(.title3.bold())
                Text(doctor.specialization)
                    .font(.subheadline)
                    .foregroundStyle(AppTheme.teal)
                Text("\(doctor.experienceYears) years experience")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text("Available: \(doctor.availabilityText)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(16)
        .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 20))
        .accessibilityElement(children: .combine)
    }

    private var dateSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Select date")
                .font(.title3.bold())
            DatePicker(
                "Select date",
                selection: $selectedDate,
                in: Self.earliestDate...Self.latestDate,
                displayedComponents: .date
            )
            .datePickerStyle(.graphical)
            .labelsHidden()
            .padding(8)
            .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 20))
        }
    }

    @ViewBuilder
    private var slotsSection: some View {
        Text("Available time slots")
            .font(.title3.bold())

        if !isAvailableDay {
            Text("\(doctor.name) is not available on this day. Available days: \(doctor.availabilityText).")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .padding(14)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 16))
        } else {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 96), spacing: 10)], spacing: 10) {
                ForEach(doctor.slots, id: \.self) { slot in
                    slotButton(slot)
                }
            }
        }
    }

    private func slotButton(_ slot: String) -> some View {
        let taken = store.isSlotTaken(doctorID: doctor.id, dateKey: dateKey, slot: slot)
        let selected = selectedSlot == slot
        let timeText = SlotFormatter.display(slot)

        return Button {
            selectedSlot = slot
        } label: {
            Text(taken ? "Booked" : timeText)
                .font(.subheadline.weight(.semibold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .background(selected ? AppTheme.primaryBlue : AppTheme.card,
                            in: RoundedRectangle(cornerRadius: 12))
                .foregroundStyle(selected ? Color.white : (taken ? Color.secondary : Color.primary))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(AppTheme.primaryBlue.opacity(0.3), lineWidth: 1)
                )
        }
        .disabled(taken)
        .accessibilityLabel(taken ? "\(timeText), already booked" : timeText)
    }

    private var confirmButton: some View {
        Button {
            showConfirm = true
        } label: {
            Text("Confirm Appointment")
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(selectedSlot == nil ? Color.gray.opacity(0.4) : AppTheme.primaryBlue,
                            in: RoundedRectangle(cornerRadius: 16))
                .foregroundStyle(.white)
        }
        .disabled(selectedSlot == nil)
    }

    private var note: some View {
        Text("Demo mode: this booking is saved on this phone only and is not sent to any hospital.")
            .font(.caption)
            .foregroundStyle(.secondary)
            .frame(maxWidth: .infinity, alignment: .center)
            .multilineTextAlignment(.center)
    }

    // MARK: - Actions

    private func book() {
        guard let slot = selectedSlot else { return }

        switch store.book(doctor: doctor, date: selectedDate, slot: slot) {
        case .success:
            resultTitle = "Appointment Booked"
            resultMessage = "Saved in demo mode. You can see it in the Appointments tab."
        case .failure(let error):
            resultTitle = "Could not book"
            resultMessage = error.localizedDescription
        }

        selectedSlot = nil
        showResult = true
    }
}

#Preview {
    NavigationStack {
        DoctorDetailView(doctor: SampleDoctors.all[0])
    }
    .environment(AppointmentStore())
}
