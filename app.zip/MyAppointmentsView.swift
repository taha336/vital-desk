import SwiftUI

struct MyAppointmentsView: View {
    @Environment(AppointmentStore.self) private var store
    @State private var appointmentToCancel: Appointment?

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.background.ignoresSafeArea()

                if store.appointments.isEmpty {
                    ContentUnavailableView(
                        "No appointments yet",
                        systemImage: "calendar",
                        description: Text("Tap + to book an appointment with a doctor.")
                    )
                } else {
                    ScrollView {
                        VStack(spacing: 12) {
                            ForEach(store.sortedAppointments) { appointment in
                                card(appointment)
                            }
                        }
                        .padding(16)
                    }
                }
            }
            .navigationTitle("Appointments")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    NavigationLink {
                        DoctorListView()
                    } label: {
                        Image(systemName: "plus")
                    }
                    .accessibilityLabel("Book new appointment")
                }
            }
            .alert(
                "Cancel appointment?",
                isPresented: Binding(
                    get: { appointmentToCancel != nil },
                    set: { if !$0 { appointmentToCancel = nil } }
                ),
                presenting: appointmentToCancel
            ) { appointment in
                Button("Yes, cancel", role: .destructive) {
                    store.cancel(appointment)
                }
                Button("Keep", role: .cancel) {}
            } message: { appointment in
                Text("\(appointment.doctorName)\n\(appointment.displayDate) at \(SlotFormatter.display(appointment.slot))")
            }
        }
    }

    private func card(_ appointment: Appointment) -> some View {
        let isConfirmed = appointment.status == .confirmed

        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(appointment.doctorName)
                    .font(.headline)
                Spacer()
                Text(isConfirmed ? "Confirmed" : "Cancelled")
                    .font(.caption.bold())
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background((isConfirmed ? AppTheme.teal : Color.gray).opacity(0.15), in: Capsule())
                    .foregroundStyle(isConfirmed ? AppTheme.teal : Color.gray)
            }

            Text(appointment.specialization)
                .font(.subheadline)
                .foregroundStyle(.secondary)

            Label("\(appointment.displayDate), \(SlotFormatter.display(appointment.slot))",
                  systemImage: "calendar")
                .font(.subheadline)

            if isConfirmed {
                Button(role: .destructive) {
                    appointmentToCancel = appointment
                } label: {
                    Label("Cancel appointment", systemImage: "xmark.circle")
                        .font(.subheadline)
                }
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 20))
        .shadow(color: .black.opacity(0.06), radius: 8, y: 4)
        .opacity(isConfirmed ? 1 : 0.7)
    }
}

#Preview {
    MyAppointmentsView()
        .environment(AppointmentStore())
}
