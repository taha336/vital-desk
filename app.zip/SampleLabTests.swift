import Foundation

/// SAMPLE DATA FOR TESTING ONLY.
/// Test names and prices here are NOT real lab data.
/// A real catalogue must come from a licensed laboratory backend.
enum SampleLabTests {
    static let all: [LabTest] = [
        LabTest(id: "sample-lab-1", name: "Complete Blood Count (CBC)",
                description: "Common blood test panel", price: 350),
        LabTest(id: "sample-lab-2", name: "Blood Sugar (Fasting)",
                description: "Blood glucose measurement", price: 120),
        LabTest(id: "sample-lab-3", name: "Lipid Profile",
                description: "Blood fat levels panel", price: 600),
        LabTest(id: "sample-lab-4", name: "Thyroid Profile (TSH)",
                description: "Thyroid hormone measurement", price: 450),
        LabTest(id: "sample-lab-5", name: "Liver Function Test",
                description: "Liver related blood panel", price: 700),
        LabTest(id: "sample-lab-6", name: "Urine Routine",
                description: "Routine urine examination", price: 150)
    ]
}
