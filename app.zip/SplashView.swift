import SwiftUI

struct SplashView: View {
    @State private var animate = false

    var body: some View {
        ZStack {
            AppTheme.brandGradient
                .ignoresSafeArea()

            VStack(spacing: 16) {
                Image(systemName: "cross.case.fill")
                    .font(.system(size: 76))
                    .foregroundStyle(.white)
                    .scaleEffect(animate ? 1 : 0.5)
                    .opacity(animate ? 1 : 0)

                Text("VITALDESK")
                    .font(.system(size: 34, weight: .heavy, design: .rounded))
                    .tracking(3)
                    .foregroundStyle(.white)
                    .opacity(animate ? 1 : 0)
                    .offset(y: animate ? 0 : 12)

                Text("Your hospital, digitally")
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.85))
                    .opacity(animate ? 1 : 0)
            }
            .accessibilityElement(children: .combine)
        }
        .onAppear {
            withAnimation(.spring(response: 0.8, dampingFraction: 0.65)) {
                animate = true
            }
        }
    }
}

#Preview {
    SplashView()
}
