import Foundation
import Observation

@Observable
final class AuthViewModel {
    private let service: any AuthService

    private(set) var currentUser: AuthUser?
    private(set) var isLoading = false
    var errorMessage: String?

    var isLoggedIn: Bool { currentUser != nil }

    init(service: any AuthService = LocalAuthService()) {
        self.service = service
        self.currentUser = service.restoreSession()
    }

    @MainActor
    @discardableResult
    func login(email: String, password: String) async -> Bool {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }

        do {
            currentUser = try await service.login(email: email, password: password)
            return true
        } catch {
            errorMessage = error.localizedDescription
            return false
        }
    }

    @MainActor
    @discardableResult
    func register(name: String, email: String, password: String) async -> Bool {
        isLoading = true
        errorMessage = nil
        defer { isLoading = false }

        do {
            currentUser = try await service.register(name: name, email: email, password: password)
            return true
        } catch {
            errorMessage = error.localizedDescription
            return false
        }
    }

    func clearError() {
        errorMessage = nil
    }

    func logout() {
        service.logout()
        currentUser = nil
        errorMessage = nil
    }
}
