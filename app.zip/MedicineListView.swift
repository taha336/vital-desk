import SwiftUI

struct MedicineListView: View {
    @Environment(CartStore.self) private var cart

    private enum RxFilter: String, CaseIterable, Identifiable {
        case all = "All"
        case noRx = "No prescription"
        case rx = "Prescription"
        var id: String { rawValue }
    }

    @State private var searchText = ""
    @State private var rxFilter: RxFilter = .all
    @State private var selectedCategory: MedicineCategory?

    private var medicines: [Medicine] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return SampleMedicines.all.filter { medicine in
            let matchesSearch = query.isEmpty || medicine.name.lowercased().contains(query)

            let matchesRx: Bool
            switch rxFilter {
            case .all: matchesRx = true
            case .noRx: matchesRx = !medicine.requiresPrescription
            case .rx: matchesRx = medicine.requiresPrescription
            }

            let matchesCategory = selectedCategory == nil || medicine.category == selectedCategory
            return matchesSearch && matchesRx && matchesCategory
        }
    }

    var body: some View {
        ZStack {
            AppTheme.background.ignoresSafeArea()

            ScrollView {
                VStack(spacing: 14) {
                    demoBanner
                    SearchBar(text: $searchText, placeholder: "Search medicines")

                    Picker("Prescription filter", selection: $rxFilter) {
                        ForEach(RxFilter.allCases) { filter in
                            Text(filter.rawValue).tag(filter)
                        }
                    }
                    .pickerStyle(.segmented)

                    categoryChips

                    if medicines.isEmpty {
                        ContentUnavailableView(
                            "No medicines found",
                            systemImage: "pills",
                            description: Text("Try a different search or filter.")
                        )
                    } else {
                        ForEach(medicines) { medicine in
                            MedicineRow(medicine: medicine)
                        }
                    }
                }
                .padding(16)
            }
        }
        .navigationTitle("Medicines")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                NavigationLink {
                    CartView()
                } label: {
                    Image(systemName: "cart.fill")
                        .overlay(alignment: .topTrailing) {
                            if cart.totalItems > 0 {
                                Text("\(cart.totalItems)")
                                    .font(.caption2.bold())
                                    .foregroundStyle(.white)
                                    .padding(4)
                                    .background(AppTheme.emergency, in: Circle())
                                    .offset(x: 10, y: -10)
                            }
                        }
                }
                .accessibilityLabel("Cart, \(cart.totalItems) items")
            }
        }
    }

    // MARK: - Pieces

    private var demoBanner: some View {
        Label("Sample catalogue for testing only. Prices are not real. No medical advice or dosage guidance is given. Medicines marked Prescription need a valid prescription.",
              systemImage: "exclamationmark.triangle.fill")
            .font(.caption)
            .foregroundStyle(.orange)
            .padding(12)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.orange.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
    }

    private var categoryChips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                chip("All", isSelected: selectedCategory == nil) {
                    selectedCategory = nil
                }
                ForEach(MedicineCategory.allCases) { category in
                    chip(category.rawValue, isSelected: selectedCategory == category) {
                        selectedCategory = category
                    }
                }
            }
        }
    }

    private func chip(_ title: String, isSelected: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.subheadline.weight(.semibold))
                .padding(.horizontal, 14)
                .padding(.vertical, 8)
                .background(isSelected ? AppTheme.primaryBlue : AppTheme.card, in: Capsule())
                .foregroundStyle(isSelected ? Color.white : Color.primary)
                .overlay(Capsule().stroke(AppTheme.primaryBlue.opacity(0.3), lineWidth: 1))
        }
    }
}

// MARK: - One medicine card

private struct MedicineRow: View {
    let medicine: Medicine
    @Environment(CartStore.self) private var cart

    private var quantity: Int {
        cart.quantity(of: medicine)
    }

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: medicine.category.systemImage)
                .font(.title3)
                .foregroundStyle(AppTheme.teal)
                .frame(width: 48, height: 48)
                .background(AppTheme.teal.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))

            VStack(alignment: .leading, spacing: 4) {
                Text(medicine.name)
                    .font(.headline)
                Text(medicine.packInfo)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                HStack(spacing: 8) {
                    Text(medicine.priceText)
                        .font(.subheadline.bold())
                        .foregroundStyle(AppTheme.teal)
                    if medicine.requiresPrescription {
                        Text("Prescription needed")
                            .font(.caption2.bold())
                            .foregroundStyle(.orange)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 3)
                            .background(Color.orange.opacity(0.15), in: Capsule())
                    }
                }
            }

            Spacer()

            control
        }
        .padding(14)
        .background(AppTheme.card, in: RoundedRectangle(cornerRadius: 20))
        .shadow(color: .black.opacity(0.06), radius: 8, y: 4)
    }

    @ViewBuilder
    private var control: some View {
        if quantity == 0 {
            Button {
                cart.add(medicine)
            } label: {
                Text("Add")
                    .font(.subheadline.bold())
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(AppTheme.primaryBlue, in: Capsule())
                    .foregroundStyle(.white)
            }
            .accessibilityLabel("Add \(medicine.name) to cart")
        } else {
            HStack(spacing: 10) {
                Button {
                    cart.decrease(medicine)
                } label: {
                    Image(systemName: "minus.circle.fill")
                        .font(.title3)
                }
                .accessibilityLabel("Decrease quantity")

                Text("\(quantity)")
                    .font(.subheadline.bold())
                    .frame(minWidth: 20)

                Button {
                    cart.add(medicine)
                } label: {
                    Image(systemName: "plus.circle.fill")
                        .font(.title3)
                }
                .disabled(quantity >= CartStore.maxQuantity)
                .accessibilityLabel("Increase quantity")
            }
            .foregroundStyle(AppTheme.primaryBlue)
        }
    }
}

#Preview {
    NavigationStack {
        MedicineListView()
    }
    .environment(CartStore())
}
