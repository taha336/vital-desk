import Foundation
import Observation

enum LabBookingError: LocalizedError {
    case alreadyBooked

    var errorDescription: String? {
        "You already have this test booked on that date. Please choose another date."
    }
}

@Observable
final class LabBookingStore {
    private(set) var bookings: [LabBooking] = []

    private let storageKey = "demo_lab_bookings_v1"

    init() {
        load()
    }

    /// Active bookings first (earliest date first), cancelled after
    var sortedBookings: [LabBooking] {
        bookings.sorted { first, second in
            let firstActive = first.status == .booked
            let secondActive = second.status == .booked
            if firstActive != secondActive { return firstActive }
            return first.dateKey < second.dateKey
        }
    }

    var activeCount: Int {
        bookings.filter { $0.status == .booked }.count
    }

    func isBooked(testID: String, dateKey: String) -> Bool {
        bookings.contains {
            $0.testID == testID && $0.dateKey == dateKey && $0.status == .booked
        }
    }

    func book(test: LabTest, date: Date) -> Result<LabBooking, LabBookingError> {
        let key = AppointmentStore.dateKey(for: date)

        guard !isBooked(testID: test.id, dateKey: key) else {
            return .failure(.alreadyBooked)
        }

        let booking = LabBooking(
            id: UUID(),
            testID: test.id,
            testName: test.name,
            price: test.price,
            dateKey: key,
            status: .booked,
            createdAt: Date()
        )
        bookings.append(booking)
        save()
        return .success(booking)
    }

    func cancel(_ booking: LabBooking) {
        guard let index = bookings.firstIndex(where: { $0.id == booking.id }) else { return }
        bookings[index].status = .cancelled
        save()
    }

    // MARK: - Saving on this phone (demo only)

    private func save() {
        if let data = try? JSONEncoder().encode(bookings) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let saved = try? JSONDecoder().decode([LabBooking].self, from: data) else { return }
        bookings = saved
    }
}
