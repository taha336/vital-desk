import Foundation
import Observation

enum BookingError: LocalizedError {
    case slotTaken

    var errorDescription: String? {
        "This time slot is already booked. Please choose another slot."
    }
}

@Observable
final class AppointmentStore {
    private(set) var appointments: [Appointment] = []

    private let storageKey = "demo_appointments_v1"

    init() {
        load()
    }

    static func dateKey(for date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }

    /// Confirmed first (earliest first), cancelled after
    var sortedAppointments: [Appointment] {
        appointments.sorted { first, second in
            let firstConfirmed = first.status == .confirmed
            let secondConfirmed = second.status == .confirmed
            if firstConfirmed != secondConfirmed { return firstConfirmed }
            if first.dateKey != second.dateKey { return first.dateKey < second.dateKey }
            return first.slot < second.slot
        }
    }

    func isSlotTaken(doctorID: String, dateKey: String, slot: String) -> Bool {
        appointments.contains {
            $0.doctorID == doctorID &&
            $0.dateKey == dateKey &&
            $0.slot == slot &&
            $0.status == .confirmed
        }
    }

    func book(doctor: Doctor, date: Date, slot: String) -> Result<Appointment, BookingError> {
        let key = Self.dateKey(for: date)

        // Duplicate booking check
        guard !isSlotTaken(doctorID: doctor.id, dateKey: key, slot: slot) else {
            return .failure(.slotTaken)
        }

        let appointment = Appointment(
            id: UUID(),
            doctorID: doctor.id,
            doctorName: doctor.name,
            specialization: doctor.specialization,
            dateKey: key,
            slot: slot,
            status: .confirmed,
            createdAt: Date()
        )
        appointments.append(appointment)
        save()
        return .success(appointment)
    }

    func cancel(_ appointment: Appointment) {
        guard let index = appointments.firstIndex(where: { $0.id == appointment.id }) else { return }
        appointments[index].status = .cancelled
        save()
    }
    
    func clearAll() {
        appointments.removeAll()
        save()
    }

    // MARK: - Saving on this phone (demo only)

    private func save() {
        if let data = try? JSONEncoder().encode(appointments) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let saved = try? JSONDecoder().decode([Appointment].self, from: data) else { return }
        appointments = saved
    }
}
