import SwiftUI

/// Shows the login screen or the main app, depending on login state.
struct RootView: View {
    @Environment(AuthViewModel.self) private var auth

    var body: some View {
        Group {
            if auth.isLoggedIn {
                MainTabView()
            } else {
                LoginView()
            }
        }
        .animation(.easeInOut(duration: 0.3), value: auth.isLoggedIn)
    }
}

#Preview {
    RootView()
        .environment(AuthViewModel())
        .environment(AppointmentStore())
        .environment(CartStore())
        .environment(LabBookingStore())
}
