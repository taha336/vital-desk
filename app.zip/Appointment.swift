import Foundation

struct Appointment: Identifiable, Codable, Hashable {
    enum Status: String, Codable {
        case confirmed
        case cancelled
    }

    let id: UUID
    let doctorID: String
    let doctorName: String
    let specialization: String
    /// Date as text, e.g. "2026-10-12"
    let dateKey: String
    /// Time in 24-hour format, e.g. "14:00"
    let slot: String
    var status: Status
    let createdAt: Date

    var displayDate: String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        guard let date = formatter.date(from: dateKey) else { return dateKey }
        return date.formatted(date: .abbreviated, time: .omitted)
    }
}

/// Converts "14:00" into "2:00 PM"
enum SlotFormatter {
    static func display(_ slot: String) -> String {
        let input = DateFormatter()
        input.locale = Locale(identifier: "en_US_POSIX")
        input.dateFormat = "HH:mm"

        let output = DateFormatter()
        output.locale = Locale(identifier: "en_US_POSIX")
        output.dateFormat = "h:mm a"

        guard let date = input.date(from: slot) else { return slot }
        return output.string(from: date)
    }
}
