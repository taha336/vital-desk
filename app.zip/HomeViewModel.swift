import Foundation
import Observation

@Observable
final class HomeViewModel {
    var searchText: String = ""

    var greeting: String {
        let hour = Calendar.current.component(.hour, from: Date())
        switch hour {
        case 5..<12: return "Good morning"
        case 12..<17: return "Good afternoon"
        case 17..<22: return "Good evening"
        default: return "Hello"
        }
    }

    var filteredServices: [ServiceType] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !query.isEmpty else { return ServiceType.allCases }
        return ServiceType.allCases.filter { $0.searchKeywords.contains(query) }
    }
}
